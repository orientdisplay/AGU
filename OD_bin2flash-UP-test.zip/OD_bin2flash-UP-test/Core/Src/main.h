#include "stm32g0xx_hal.h"
#include "stm32g0xx_ll_dma.h"
#include "stm32g0xx_ll_rcc.h"
#include "stm32g0xx_ll_bus.h"
#include "stm32g0xx_ll_system.h"
#include "stm32g0xx_ll_exti.h"
#include "stm32g0xx_ll_cortex.h"
#include "stm32g0xx_ll_utils.h"
#include "stm32g0xx_ll_pwr.h"
#include "stm32g0xx_ll_usart.h"
#include "stm32g0xx_ll_gpio.h"
#include "core_cm0plus.h"
#include "system_stm32g0xx.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"

#define RED 0xf800
#define GREEN 0x07e0
#define BLUE 0x001f
#define WHITE 0xffff
#define YELLOW 0xffe0

#define TFT_0140_128128  0
#define TFT_0177_0240_0280_240320  1


#if (TFT_0140_128128)
	#define  ASCII8x16_SIZE      1520
	#define  TEXT16x16_SIZE      766080

	#define  ASCII8x16_ADDR       0
	#define  TEXT16x16_ADDR       ASCII8x16_ADDR+ASCII8x16_SIZE
	#define  PIC_ADDR       			TEXT16x16_ADDR+TEXT16x16_SIZE

#elif (TFT_0177_0240_0280_240320)
	#define  ASCII8x16_SIZE       1520
	#define  TEXT16x16_SIZE       766080
	#define  ASCII16x24_SIZE      4560
	#define  TEXT24x24_SIZE       1723680
	#define  ASCII16x32_SIZE      6080
	#define  TEXT32x32_SIZE       3064320

	#define  ASCII8x16_ADDR       0
	#define  TEXT16x16_ADDR       ASCII8x16_ADDR  + ASCII8x16_SIZE    //1520
	#define  ASCII16x24_ADDR      TEXT16x16_ADDR  + TEXT16x16_SIZE    //767600
	#define  TEXT24x24_ADDR       ASCII16x24_ADDR + ASCII16x24_SIZE   //772160
	#define  ASCII16x32_ADDR      TEXT24x24_ADDR  + TEXT24x24_SIZE    //2495840
	#define  TEXT32x32_ADDR       ASCII16x32_ADDR + ASCII16x32_SIZE   //2501920
	#define  PIC_ADDR       			TEXT32x32_ADDR  + TEXT32x32_SIZE    //5566240
#endif

const uint32_t PIC_INFO[3][3]=
{
  /*Width , Height , Start Address  */ 
#if TFT_0140_128128
  {128,128,0},            /*     0 PIC1     */
  {68,68,32768},          /*     1 PCI2     */

#elif TFT_0177_0240_0280_240320
  {240,320,0},           /*     0 PIC1     */
  {320,240,153600},      /*     1 PIC2     */
  {120,120,307200},      /*     2 PIC3     */
	
#endif
};

//-----usart.c---------------
extern void USART1_Init(uint32_t baud);//串口初始化(Initializing serial port)
extern void UART1_Send_NBytes(uint8_t *Data, uint16_t Len);//发送多个字节(Send multiple bytes)
extern void UART1_Send_NChars(char * dat);//发送多个字符(Send multiple characters)
extern uint8_t  USART_RX_BUFF[]; //SIZE = 520
uint8_t  USART_BUFF[520]; //SIZE = 520
extern uint16_t USART1_RX_STA;   //接收状态标记(Receiving status marker)	bit15:一帧数据完成(A frame of data is completed)   bit14-0:一帧数据长度(The data length of a frame)

extern void TF_CS_L(void);
extern void TF_CS_H(void);
//-----sysclk.c---------------
extern void SystemClock_Config(void);//系统时钟初始化(Initialize the system clock)
////-----fat.c---------------
extern void TF_SPIGPIO_Init_32M(void);//初始化TF_SPI时钟为32MHZ(Initialize the TF_SPI clock to 32MHZ)
extern uint8_t UART2FLASH_Binfile(uint8_t DelayNms);//从TF卡中读BIN文件并通过串口发送给UART LCM，延时设置为0ms(读TF卡时本身有延时1ms,只有在低波特率时才用)(Read BIN files from TF card and send them to UART LCM through serial port, with delay set to 0ms(there is a delay of 1ms when reading TF card, only used at low baud rate))
extern uint8_t SPI2FLASH_Binfile(uint8_t FormatAllChipYesNo,uint32_t WriteAddr);//从TF卡中读BIN文件并通过SPI发送给SPI LCM(Read the BIN file from the TF card and send it to SPI LCM via SPI)

