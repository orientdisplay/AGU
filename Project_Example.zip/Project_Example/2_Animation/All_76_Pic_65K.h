/*********************************************************************/
//
//	brief: This file provides an easy way to obtain image data information.
//
//
//	BINARY_INFO[PICTURE_NAME].number      => To obtain sequence number information of the "PICTURE_NAME"(.bmp or .jpg) which is generated in the excel file
//	BINARY_INFO[PICTURE_NAME].img_width       => To obtain image width information of the "PICTURE_NAME" (.bmp or .jpg)
//	BINARY_INFO[PICTURE_NAME].img_height      => To obtain image height information of the "PICTURE_NAME" (.bmp or .jpg)
//	BINARY_INFO[PICTURE_NAME].img_size        => To obtain an image size which is converted and stored in the binary file, please notice, the binary file is combined and converted from the several files (.bmp or .jpg)
//	BINARY_INFO[PICTURE_NAME].start_addr  => To obtain start address of binary file which is converted from the file "PICTURE_NAME" (.bmp or .jpg)
//
//	For example, the struct and enum type as:
//
//	const INFO (code) BINARY_INFO[3]=
//	{
//  	/*  No. , Width , Height , Size (bytes) , Start Address  */
//  	{1,1280,800,2048000,0},          /*     pic_01_1280x800 , element 0     */
//  	{2,320,240,153600,2048000},      /*     RAiO , element 1     */
//  	{3,128,128,32768,2201600},       /*     S1_16 , element 2     */
//	}
//
//
//  typedef enum
//  {
//    pic_01_1280x800=0,  /*     0     */
//    RAiO,               /*     1     */
//    S1_16,              /*     2     */
//  }PICTURE_NAME;
//
//	(1).  To obtain size informations of the file "pic_01_1280x800" (.bmp or jpg),
//        the C code is:
//
//									long param1 = 0;
//
//									param1 = BINARY_INFO[pic_01_1280x800].img_size;
//									/*  or  */
//									param1 = BINARY_INFO[0].img_size;
//
//									/* the param1 is 2048000 (bytes) */
//
//
//	(2).  To obtain start address informations of the file "S1_16" (.bmp or jpg),
//        the C code is:
//
//									long param2 = 0;
//
//									param2 = BINARY_INFO[S1_16].start_addr;
//									/*  or  */
//									param2 = BINARY_INFO[2].start_addr;
//
//									/* the param2 is 2201600 (bytes) */
//
/*********************************************************************/
typedef struct _info
{
  unsigned short number;
  unsigned short img_width;
  unsigned short img_height;
  unsigned long img_size;
  unsigned long start_addr;
}INFO;

  /* The 'code' is KEIL C 8051 instruction, please refer to http://www.keil.com/support/man/docs/c51/c51_le_code.htm */
  /* If you do not use the 8051 microcontroller system, please remove the 'code' instruction. */

const INFO code BINARY_INFO[27]=
{
  /*  No. , Width , Height , Size , Start Address  */ 
  {1,24,48,2304,0},          /*     0 , element 0     */
  {2,24,48,2304,2304},          /*     1 , element 1     */
  {3,24,48,2304,4608},          /*     2 , element 2     */
  {4,24,48,2304,6912},          /*     3 , element 3     */
  {5,24,48,2304,9216},          /*     4 , element 4     */
  {6,24,48,2304,11520},          /*     5 , element 5     */
  {7,24,48,2304,13824},          /*     6 , element 6     */
  {8,24,48,2304,16128},          /*     7 , element 7     */
  {9,24,48,2304,18432},          /*     8 , element 8     */
  {10,24,48,2304,20736},          /*     9 , element 9     */
  {11,12,48,1152,23040},          /*     10 , element 10     */
  {12,12,48,1152,24192},          /*     11 , element 11     */
  {13,12,48,1152,25344},          /*     12 , element 12     */
  {14,12,48,1152,26496},          /*     13 , element 13     */
  {15,24,48,2304,27648},          /*     15 , element 14     */
  {16,24,48,2304,29952},          /*     16 , element 15     */
  {17,24,48,2304,32256},          /*     17 , element 16     */
  {18,24,48,2304,34560},          /*     18 , element 17     */
  {19,24,48,2304,36864},          /*     19 , element 18     */
  {20,24,48,2304,39168},          /*     20 , element 19     */
  {21,24,48,2304,41472},          /*     21 , element 20     */
  {22,24,48,2304,43776},          /*     22 , element 21     */
  {23,68,79,10744,46080},          /*     0 , element 22     */
  {24,68,79,10744,56824},          /*     1 , element 23     */
  {25,68,79,10744,67568},          /*     2 , element 24     */
  {26,68,79,10744,78312},          /*     3 , element 25     */
  {27,68,79,10744,89056},          /*     4 , element 26     */
};

typedef enum
{
  0=0,          /*     0     */
  1,          /*     1     */
  2,          /*     2     */
  3,          /*     3     */
  4,          /*     4     */
  5,          /*     5     */
  6,          /*     6     */
  7,          /*     7     */
  8,          /*     8     */
  9,          /*     9     */
  10,          /*     10     */
  11,          /*     11     */
  12,          /*     12     */
  13,          /*     13     */
  15,          /*     14     */
  16,          /*     15     */
  17,          /*     16     */
  18,          /*     17     */
  19,          /*     18     */
  20,          /*     19     */
  21,          /*     20     */
  22,          /*     21     */
  0,          /*     22     */
  1,          /*     23     */
  2,          /*     24     */
  3,          /*     25     */
  4,          /*     26     */
}PICTURE_NAME;

